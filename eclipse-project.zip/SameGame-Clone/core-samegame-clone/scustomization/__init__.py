from control_panel_settings import *
from instructions_settings import *
from bubble_settings import *
from game_settings import *