'''
Created on Mar 26, 2016

@author: Richard
'''
BUBBLE_MARGIN = 2