'''
Created on Oct 26, 2014

@author: Richard
'''
FILE_PROCESSING_IMAGE_DIRECTORY = "files/images"
FILE_PROCESSING_SOUND_DIRECTORY = "files/sounds"
FILE_PROCESSING_MUSIC_DIRECTORY = "files/music"
FILE_PROCESSING_LEVEL_DIRECTORY = "files/levels"
FILE_PROCESSING_FONT_DIRECTORY = "files/fonts"
