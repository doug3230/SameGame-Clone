'''
Created on Oct 13, 2014

@author: Richard
'''
from pygame import Surface
COMPONENTS_CAPTION = "Same Game Clone"
COMPONENTS_ICON = None
COMPONENTS_EMPTY_ICON = Surface((0, 0))
COMPONENTS_DOUBLE_BUFFERED = True
COMPONENTS_RESIZABLE = False
COMPONENTS_FPS = 30
