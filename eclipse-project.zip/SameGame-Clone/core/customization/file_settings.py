'''
Created on Oct 26, 2014

@author: Richard
'''
FILE_IMAGE_DIRECTORY = "files/images"
FILE_SOUND_DIRECTORY = "files/sounds"
FILE_MUSIC_DIRECTORY = "files/music"
FILE_LEVEL_DIRECTORY = "files/levels"
FILE_FONT_DIRECTORY = "files/fonts"
